╔══════════════════════════════════════════════════════════════════════╗
║  TAKEDA — PROCESSAR FATURA POR EMAIL                                ║
║  Power Automate Cloud Flow — Pacote de Importação                   ║
╚══════════════════════════════════════════════════════════════════════╝

COMO IMPORTAR
─────────────
1. Acesse https://make.powerautomate.com
2. Menu esquerdo → Meus fluxos → Importar → Importar Pacote (Legado)
3. Selecione este arquivo ZIP
4. Na tela de revisão, configure as três conexões:
   • Office 365 Outlook  → sua conta corporativa Takeda
   • Excel Online (Business) → sua conta M365
   • AI Builder          → mesma conta M365
5. Clique em Importar

O QUE O FLUXO FAZ
──────────────────
Quando um novo email chegar com anexo PDF:
  1. Detecta automaticamente arquivos .pdf no email
  2. Obtém o conteúdo do PDF
  3. AI Builder (Invoice Processing prebuilt) extrai:
       • Fornecedor / Razão Social
       • Número NF / Boleto
       • Data de Emissão
       • Data de Vencimento
       • Valor Líquido (SubTotal)
       • Impostos
       • Valor Total (AmountDue)
  4. Extrai o nome do evento e referência do assunto/nome do arquivo
  5. Grava nova linha na tabela tblPOsMigrado (aba Acompanhamento de POs)
  6. Envia email de confirmação do registro

CONFIGURAÇÃO PÓS-IMPORTAÇÃO  ← OBRIGATÓRIO
────────────────────────────
Na ação "Adicionar linha em POs", configure:
  • Localização : SharePoint ou OneDrive for Business
  • Biblioteca  : Documentos (ou onde está o arquivo)
  • Arquivo     : /Shared Documents/Takeda_Events_2026_Enterprise.xlsx
  • Tabela      : tblPOsMigrado

Para filtrar apenas emails de faturamento, no gatilho configure:
  • Assunto contém: Fatura, Boleto, NF, Fee, BL_
  • Pasta: Caixa de Entrada ou subpasta específica

PRÉ-REQUISITOS
──────────────
• Licença Microsoft 365 com AI Builder (plano que inclua AI Builder credits)
• Arquivo Takeda_Events_2026_Enterprise.xlsx salvo no SharePoint/OneDrive
• Conexões configuradas: Outlook, Excel Online Business, AI Builder

CAMPOS EXTRAÍDOS → COLUNAS DA PLANILHA
──────────────────────────────────────
  EventID                → (EventID extraído do assunto do email)
  Nome do Evento         → (nome do evento extraído do assunto)
  Fornecedor             → AI Builder: VendorName
  Tipo de Despesa        → (extraído do nome do arquivo)
  Categoria GL           → (vazio — preencher manualmente)
  Nº PO                  → (vazio — preencher manualmente)
  Nº NF                  → AI Builder: InvoiceId
  Valor Líquido (R$)     → AI Builder: SubTotal
  Imposto (R$)           → AI Builder: TotalTax
  Valor Total (R$)       → AI Builder: AmountDue
  Status Pagamento       → "Aguardando NF" (padrão)
  Data Emissão           → AI Builder: InvoiceDate
  Data Vencimento        → AI Builder: DueDate
  Data Pagamento         → (vazio)
  Forma Pagamento        → "Boleto" (detectado do tipo BL_)
  Banco / Conta          → (vazio)
  Observações            → Assunto do email + nome do arquivo
  Flag Over Budget       → (vazio)
  Flag Atraso >30d       → (vazio)

SUPORTE
───────
Desenvolvido para uso interno Takeda Brasil.
Arquivo Excel de referência: Takeda_Events_2026_Enterprise.xlsx
