╔══════════════════════════════════════════════════════════════════════╗
║  TAKEDA — PROCESSAMENTO AUTOMÁTICO DE FATURAS (VERSÃO 2026)         ║
║  Power Automate Cloud Flow — Arquitetura Enterprise                 ║
╚══════════════════════════════════════════════════════════════════════╝

VISÃO GERAL
───────────
Este fluxo automatiza o processamento de faturas (NF/Boleto) recebidas por email,
extraindo dados via AI Builder e integrando ao modelo estruturado "Pharma Events Operations Enterprise 2026".

Arquitetura:
Email → Extração → Staging → Validação → Enriquecimento → Carga final → Log

---

COMO IMPORTAR
─────────────
- Acesse https://make.powerautomate.com
- Menu → Meus fluxos → Importar → Importar Pacote (Legado)
- Selecione o arquivo ZIP
- Configure as conexões:
  • Office 365 Outlook (conta corporativa)
  • Excel Online (Business)
  • AI Builder
- Após importar:
  • Abrir ação "Adicionar linha"
  • Reconfigurar caminho do Excel (resolver File ID)

---

COMO O FLUXO FUNCIONA
─────────────────────
Quando um novo email chega:

1. Filtra emails com anexos PDF
2. Extrai conteúdo do arquivo
3. AI Builder (Invoice Processing) captura:
   - Fornecedor
   - Nº NF
   - Data emissão
   - Data vencimento
   - Valores (líquido, imposto, total)

4. Extrai EventID via padrão:
   EVT-YYYY-XXX (regex)

5. Grava os dados na tabela:
   → tbl_Invoices_Staging

---

TABELAS UTILIZADAS
──────────────────

1. STAGING (obrigatória)
Tabela: tbl_Invoices_Staging

Campos:
- RawEmailSubject
- FileName
- EventID
- Vendor
- InvoiceId
- Amount
- Status ("Pending Validation")
- ErrorFlag

---

2. TABELA FINAL (modelo 2026)
Tabela: Cost Control (ou equivalente no modelo Enterprise)

Campos preenchidos:
- EventID
- Supplier
- Cost Category
- Invoice Number
- Actual Cost
- Invoice Date
- Due Date
- Payment Status

---

VALIDAÇÕES
──────────
- EventID deve existir no Event Master
- Valor > 0
- Vendor obrigatório
- Datas válidas

Se falhar:
→ Registro permanece na staging com status "Error"

---

ENRIQUECIMENTO
──────────────
O fluxo busca automaticamente:

- Event Master:
  • BU
  • Produto

- Supplier Mapping:
  • Categoria GL (quando disponível)

---

FLAGS AUTOMÁTICAS
─────────────────
- Over Budget:
  Actual > Planned

- Delay:
  Today > DueDate + 30 dias

---

LOG E MONITORAMENTO
───────────────────
Tabela: tbl_Flow_Log

Campos:
- Timestamp
- EventID
- Status
- ErrorMessage
- FileName

---

PRÉ-REQUISITOS
──────────────
- Licença M365 com AI Builder credits
- Arquivo hospedado no OneDrive for Business
- Modelo 2026 estruturado (Event Master + Cost Control)

---

REGRAS IMPORTANTES
──────────────────
- NÃO usar tabela legado tblPOsMigrado
- NÃO escrever diretamente na tabela final sem validação
- NÃO depender de parsing livre (sempre usar padrão EVT)

---

RECOMENDAÇÃO CRÍTICA
────────────────────
Padronizar emails de entrada:

Exemplo:
Assunto:
EVT-2026-015 | Fornecedor X | NF 12345

Sem padrão:
→ fluxo falha
→ dados inconsistentes

---

DESENVOLVIDO PARA:
Gestão financeira integrada de eventos Takeda Brasil (modelo Enterprise 2026)
