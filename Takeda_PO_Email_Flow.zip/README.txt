╔══════════════════════════════════════════════════════════════════════╗
║  TAKEDA — PROCESSAR FATURA POR EMAIL                                ║
║  Power Automate Cloud Flow — Pacote de Importação                   ║
╚══════════════════════════════════════════════════════════════════════╝

COMO IMPORTAR
─────────────
1. Acesse https://make.powerautomate.com
2. Menu esquerdo → Meus fluxos → Importar → Importar Pacote (Legado)
3. Selecione este arquivo ZIP
4. Na tela de revisão, configure as três conexões:
   • Office 365 Outlook  → sua conta corporativa Takeda (eo2455)
   • Excel Online (Business) → mesma conta M365
   • AI Builder          → mesma conta M365
5. Clique em Importar

O QUE O FLUXO FAZ
──────────────────
Quando um novo email chegar com anexo PDF:
  1. Detecta automaticamente arquivos .pdf no email
  2. Obtém o conteúdo do PDF
  3. AI Builder (Invoice Processing prebuilt) extrai:
       • Fornecedor / Razão Social
       • Número NF / Boleto
       • Data de Emissão
       • Data de Vencimento
       • Valor Líquido (SubTotal)
       • Impostos
       • Valor Total (AmountDue)
  4. Extrai nome do evento e referência do assunto/nome do arquivo
  5. Classifica Tipo de Despesa e Forma de Pagamento pelo nome do arquivo
  6. Grava nova linha na tabela tblPOsMigrado (aba Acompanhamento de POs)
  Nenhum email é enviado de volta.

ARQUIVO DE DESTINO (já configurado no fluxo)
────────────────────────────────────────────
  OneDrive for Business:
  /02 - GESTÃO & CONTROLE/Não Apagar/Controle Geral de Eventos 2025.xlsx
  Tabela: tblPOsMigrado

  ⚠️  ATENÇÃO: após importar, abra a ação "Adicionar_linha_em_POs"
  no designer e selecione o arquivo pelo seletor de arquivos.
  O caminho é pré-preenchido mas o drive/file ID precisa ser resolvido
  pelo Power Automate uma vez. Navegue até o arquivo e salve.

FILTRO RECOMENDADO NO GATILHO (opcional)
────────────────────────────────────────
  No gatilho "Quando chegar novo email", adicione filtro de assunto:
  • Contém: BL_, Boleto, Fatura, NF, Fee
  Isso evita disparar para emails sem fatura.

PRÉ-REQUISITOS
──────────────
• Licença Microsoft 365 com AI Builder credits
• Arquivo Excel salvo no OneDrive for Business (caminho acima)
• Tabela tblPOsMigrado existente no arquivo

CAMPOS EXTRAÍDOS → COLUNAS DA PLANILHA
──────────────────────────────────────
  EventID                → extraído do assunto (padrão EVT-NNN)
  Nome do Evento         → extraído do assunto do email
  Fornecedor             → AI Builder: VendorName
  Tipo de Despesa        → detectado do nome do arquivo
  Categoria GL           → (vazio)
  Nº PO                  → (vazio)
  Nº NF                  → AI Builder: InvoiceId
  Valor Líquido (R$)     → AI Builder: SubTotal
  Imposto (R$)           → AI Builder: TotalTax
  Valor Total (R$)       → AI Builder: AmountDue
  Status Pagamento       → "Aguardando NF" (padrão)
  Data Emissão           → AI Builder: InvoiceDate
  Data Vencimento        → AI Builder: DueDate
  Data Pagamento         → (vazio)
  Forma Pagamento        → BL_ no nome → "Boleto"; NF → "TED/PIX"
  Banco / Conta          → (vazio)
  Observações            → Assunto + nome do arquivo + remetente
  Flag Over Budget       → (vazio)
  Flag Atraso >30d       → (vazio)

DESENVOLVIDO PARA USO INTERNO TAKEDA BRASIL
