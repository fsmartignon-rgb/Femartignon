/**
 * Download high-quality Earth textures for the globe.
 * Run: node scripts/download-textures.js
 *
 * Sources:
 *   - NASA Visible Earth (public domain)
 *   - Solar System Scope (CC BY 4.0)
 *   - three-globe examples (MIT)
 */
import { writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';
import { get } from 'https';

const DIR = join(import.meta.dirname, '..', 'public', 'textures');
if (!existsSync(DIR)) mkdirSync(DIR, { recursive: true });

const TEXTURES = [
  {
    name: 'earth_day.jpg',
    url: 'https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg',
    desc: 'Blue Marble day side (2048px)',
  },
  {
    name: 'earth_night.jpg',
    url: 'https://unpkg.com/three-globe/example/img/earth-night.jpg',
    desc: 'Night lights (2048px)',
  },
  {
    name: 'earth_bump.png',
    url: 'https://unpkg.com/three-globe/example/img/earth-topology.png',
    desc: 'Topology bump map',
  },
  {
    name: 'earth_water.png',
    url: 'https://unpkg.com/three-globe/example/img/earth-water.png',
    desc: 'Ocean specular mask',
  },
  {
    name: 'stars.png',
    url: 'https://unpkg.com/three-globe/example/img/night-sky.png',
    desc: 'Star field background',
  },
];

console.log('Downloading textures to public/textures/ ...\n');

for (const tex of TEXTURES) {
  const dest = join(DIR, tex.name);
  if (existsSync(dest)) {
    console.log(`  [skip] ${tex.name} — already exists`);
    continue;
  }
  console.log(`  [download] ${tex.name} — ${tex.desc}`);
  await new Promise((resolve, reject) => {
    const follow = (url) => {
      get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          follow(res.headers.location);
          return;
        }
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          writeFileSync(dest, Buffer.concat(chunks));
          resolve();
        });
        res.on('error', reject);
      }).on('error', reject);
    };
    follow(tex.url);
  });
}

console.log('\nDone. For higher resolution (4K/8K) textures, see TEXTURES.md');
