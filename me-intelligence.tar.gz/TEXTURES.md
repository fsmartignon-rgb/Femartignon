# Texturas do Globo

## Quick start (2K, suficiente para desenvolvimento)

```bash
npm run textures
```

Baixa as texturas padrão do three-globe (2048px) para `public/textures/`.

## Upgrade para 4K/8K (produção)

Substitua os arquivos em `public/textures/` por versões de maior resolução:

| Arquivo | Resolução recomendada | Fonte |
|---|---|---|
| `earth_day.jpg` | 8192×4096 | [NASA Blue Marble](https://visibleearth.nasa.gov/images/73909) |
| `earth_night.jpg` | 8192×4096 | [NASA Black Marble](https://visibleearth.nasa.gov/images/144898) |
| `earth_bump.png` | 4096×2048 | [Solar System Scope](https://www.solarsystemscope.com/textures/) |
| `earth_water.png` | 4096×2048 | [Solar System Scope](https://www.solarsystemscope.com/textures/) |
| `clouds.png` | 4096×2048 | [Solar System Scope](https://www.solarsystemscope.com/textures/) |
| `stars.png` | 8192×4096 | [ESA/Gaia sky survey](https://sci.esa.int/gaia) |

Formatos `.webp` também funcionam — basta manter o mesmo nome base no import.

## Licenças

- NASA: Public Domain
- Solar System Scope: CC BY 4.0
- ESA/Gaia: CC BY-SA 3.0 IGO
