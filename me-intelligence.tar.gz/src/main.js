/**
 * M&E Executive Intelligence — Main Entry Point
 *
 * Orchestrates:
 *   1. Dashboard shell (hero, KPIs, ticker, chart panels)
 *   2. Three.js globe (Earth, Atmosphere, Clouds, Stars, layers)
 *   3. ECharts analytical charts
 *   4. GSAP entrance animations
 */

import * as THREE from 'three';
import * as echarts from 'echarts';
import './style.css';

// Core
import { createRenderer, handleResize } from './core/renderer.js';
import { createScene } from './core/scene.js';
import { createCamera } from './core/camera.js';
import { createControls } from './core/controls.js';
import { createLights, getSunDirection } from './core/lights.js';
import { createComposer, resizeComposer } from './core/postprocessing.js';

// Globe
import { Globe } from './globe/Globe.js';

// Layers
import { CitiesLayer } from './layers/CitiesLayer.js';
import { ArcsLayer } from './layers/ArcsLayer.js';
import { HubLayer } from './layers/HubLayer.js';
import { LabelsLayer } from './layers/LabelsLayer.js';

// Interactions
import { Hover } from './interactions/Hover.js';
import { Tooltip } from './interactions/Tooltip.js';
import { Filters } from './interactions/Filters.js';

// Animation
import { CameraFlight } from './animation/CameraFlight.js';
import { playEntrance } from './animation/Timeline.js';

// Data
import {
  META, TICKER, CITIES, HUBS, BY_UF, TA, FORMATO, BU,
  COMPLEXIDADE, TIPO, STATUS_PGTO, ANUAL, TIMELINE, FORNECEDORES, PRAZO,
} from './data/cities.js';

// ============================================================
//  UTILITIES
// ============================================================
const BRL  = v => 'R$ ' + (v >= 1e6 ? (v/1e6).toFixed(1).replace('.',',')+' M' : v >= 1e3 ? (v/1e3).toFixed(0)+'k' : v.toFixed(0));
const BRLf = v => v.toLocaleString('pt-BR',{style:'currency',currency:'BRL',maximumFractionDigits:0});
const NUM  = v => v.toLocaleString('pt-BR');

// ============================================================
//  1. RENDER DASHBOARD HTML
// ============================================================
document.getElementById('app').innerHTML = buildDashboardHTML();

function buildDashboardHTML() {
  const pctPago = (META.pago / META.valor_total * 100).toFixed(1).replace('.',',');
  const pctOpen = (META.outstanding / META.valor_total * 100).toFixed(1).replace('.',',');

  const kpis = [
    {c:'var(--accent)',l:'Total de eventos',v:NUM(META.eventos),s:`<b>${NUM(META.complexidade_alta)}</b> de complexidade alta`},
    {c:'var(--gold)',l:'Investimento total',v:BRL(META.valor_total),s:`<b>${NUM(META.pagamentos)}</b> pagamentos registrados`},
    {c:'var(--green)',l:'Valor liquidado',v:BRL(META.pago),s:`<b>${pctPago}%</b> do total movimentado`},
    {c:'var(--accent)',l:'Outstanding',v:BRL(META.outstanding),s:`<b>${pctOpen}%</b> em aberto`},
    {c:'var(--cyan)',l:'Alcance geográfico',v:NUM(META.paises),s:`<b>${NUM(CITIES.length)}</b> cidades mapeadas`},
    {c:'var(--violet)',l:'Base de fornecedores',v:NUM(META.fornecedores),s:`<b>${META.periodo}</b> de cobertura`},
  ];

  const tkItems = TICKER.map(t => `<span><i>&#9670;</i>${t.pais}<b>${t.n}</b></span>`).join('');
  const maxF = FORNECEDORES[0].valor;
  const rankHTML = FORNECEDORES.map((f,i) =>
    `<div class="rk"><div class="top"><div class="pos">${String(i+1).padStart(2,'0')}</div><div class="nm"><b title="${f.nome}">${f.nome}</b><span>${NUM(f.pgtos)} pagamentos</span></div><div class="vl">${BRL(f.valor)}</div></div><div class="bar"><i style="width:${(f.valor/maxF*100).toFixed(1)}%"></i></div></div>`
  ).join('');

  return /* html */ `<div class="wrap">
    <header class="hero">
      <div class="mark"><div class="sq">T</div><div class="tx">Takeda &middot; Meetings &amp; Events</div></div>
      <h1>M&amp;E Executive<br><em>Intelligence</em></h1>
      <p class="lede">Portfólio consolidado de <b>${NUM(META.eventos)}</b> eventos médico-científicos distribuídos em <b>${NUM(META.paises)}</b> países,
      sustentados por <b>${NUM(META.pagamentos)}</b> pagamentos e <b>${BRL(META.valor_total)}</b> movimentados entre FY2021 e FY2027.</p>
      <div class="metaline">
        <span>Fonte &middot; Single Source of Truth</span>
        <span>Cobertura &middot; FY2021 &ndash; FY2027</span>
        <span>Dimensões &middot; 9 tabelas dimensionais</span>
        <span>Status &middot; Auditado</span>
      </div>
    </header>

    <section>
      <div class="kpis">${kpis.map(k=>`<div class="kpi" style="--c:${k.c}"><div class="l">${k.l}</div><div class="v">${k.v}</div><div class="s">${k.s}</div></div>`).join('')}</div>
      <div class="ticker"><div class="tk">${tkItems}${tkItems}</div></div>
    </section>

    <section>
      <div class="shead"><h2>Alcance global &amp; distribuição de eventos</h2><div class="pill">Three.js &middot; WebGL &middot; Postprocessing</div></div>
      <div class="globe-section" id="globeSection">
        <canvas class="globe-canvas" id="globeCanvas"></canvas>
        <div class="globe-ovl globe-stats" id="globeStats"></div>
        <div class="globe-hubs" id="globeHubs"></div>
      </div>
      <div class="insight"><div>
        <div class="ic">&#127758;</div>
        <p><b>Concentração dupla.</b> São Paulo responde sozinha por parcela dominante do volume presencial doméstico,
        enquanto o eixo internacional se organiza em três hubs recorrentes — <b>Barcelona</b>, <b>Washington DC</b> e <b>Viena</b>.</p>
      </div></div>
    </section>

    <section>
      <div class="shead"><h2>Distribuição por UF (Brasil)</h2><div class="pill">13 estados ativos</div></div>
      <div class="panel"><div class="cbody"><div id="cUF" class="chart-lg"></div></div></div>
    </section>

    <section>
      <div class="shead"><h2>Timeline financeira por Business Unit</h2><div class="pill">ECharts Timeline</div></div>
      <div class="panel"><div class="cbody"><div id="cTimeline" class="chart-lg"></div></div></div>
    </section>

    <section>
      <div class="shead"><h2>Análise multidimensional</h2><div class="pill">6 dimensões</div></div>
      <div class="g6">
        <div class="panel"><div class="ph"><h3>Áreas terapêuticas</h3><p>Eventos por TA padronizada</p></div><div class="cbody"><div id="cTA" class="chart"></div></div></div>
        <div class="panel"><div class="ph"><h3>Formato</h3><p>Presencial &middot; online &middot; híbrido</p></div><div class="cbody"><div id="cFmt" class="chart"></div></div></div>
        <div class="panel"><div class="ph"><h3>Business Units</h3><p>Distribuição por BU</p></div><div class="cbody"><div id="cBU" class="chart"></div></div></div>
        <div class="panel"><div class="ph"><h3>Complexidade</h3><p>Classificação operacional</p></div><div class="cbody"><div id="cCx" class="chart"></div></div></div>
        <div class="panel"><div class="ph"><h3>Tipo de evento</h3><p>Natureza da iniciativa</p></div><div class="cbody"><div id="cTp" class="chart"></div></div></div>
        <div class="panel"><div class="ph"><h3>Status de pagamento</h3><p>Escala logarítmica</p></div><div class="cbody"><div id="cSt" class="chart"></div></div></div>
      </div>
    </section>

    <section>
      <div class="shead"><h2>Evolução financeira anual</h2><div class="pill">PO total &middot; pago &middot; eventos</div></div>
      <div class="panel"><div class="cbody"><div id="cAnual" class="chart-lg"></div></div></div>
    </section>

    <section>
      <div class="shead"><h2>Top fornecedores &amp; prazo de pagamento</h2><div class="pill">Vendor Intelligence</div></div>
      <div class="g2">
        <div class="panel"><div class="ph"><h3>Ranking por valor pago</h3><p>Top 12 fornecedores</p></div><div class="cbody"><div class="rank">${rankHTML}</div></div></div>
        <div class="panel"><div class="ph"><h3>Prazo de pagamento</h3><p>Distribuição por faixa de dias</p></div><div class="cbody"><div id="cPrazo" class="chart-lg"></div></div></div>
      </div>
    </section>

    <footer>Takeda Brasil &middot; Meetings &amp; Events &middot; M&amp;E Executive Intelligence</footer>
  </div>`;
}

// ============================================================
//  2. THREE.JS GLOBE
// ============================================================
async function initGlobe() {
  const container = document.getElementById('globeSection');
  const canvas = document.getElementById('globeCanvas');

  const scene = createScene();
  const camera = createCamera(container.clientWidth / container.clientHeight);
  const renderer = createRenderer(canvas);
  renderer.setSize(container.clientWidth, container.clientHeight);

  const controls = createControls(camera, canvas);
  const { sun } = createLights(scene);
  const sunDir = getSunDirection(sun);

  // Postprocessing
  const { composer } = createComposer(renderer, scene, camera);

  // Globe
  const textureLoader = new THREE.TextureLoader();
  const globe = new Globe();
  await globe.init(scene, sunDir, textureLoader);

  // Data layers
  const citiesLayer = new CitiesLayer(globe);
  citiesLayer.init(CITIES);

  const arcsLayer = new ArcsLayer(globe);
  arcsLayer.init(CITIES);

  const hubLayer = new HubLayer(globe);
  hubLayer.init(HUBS);

  const labelsLayer = new LabelsLayer(globe);
  labelsLayer.init(HUBS);

  // Interactions
  const hover = new Hover(camera, canvas);
  hover.setTargets([citiesLayer.mesh]);
  const tooltip = new Tooltip(container);
  hover.onHover = (hit) => hit ? tooltip.show(hit) : tooltip.hide();

  // Filters
  const filters = new Filters();
  filters.createUI(container, CITIES);
  const cameraFlight = new CameraFlight(camera, controls, globe.radius);

  filters.onChange = (regionName, filtered, view) => {
    citiesLayer.setCities(filtered);
    arcsLayer.setArcs(filtered);
    cameraFlight.flyTo(view, 1.8);
    updateGlobeStats(filtered);
  };

  // Hub buttons
  const hubsEl = document.getElementById('globeHubs');
  HUBS.forEach(h => {
    const btn = document.createElement('button');
    btn.className = 'hub-btn';
    btn.textContent = h.nome;
    btn.addEventListener('click', () => {
      controls.autoRotate = false;
      cameraFlight.flyTo({ lat: h.lat, lng: h.lon, alt: 130 }, 2.2);
    });
    hubsEl.appendChild(btn);
  });
  const resetBtn = document.createElement('button');
  resetBtn.className = 'hub-btn';
  resetBtn.textContent = 'Voltar ao globo';
  resetBtn.addEventListener('click', () => cameraFlight.reset(2.0));
  hubsEl.appendChild(resetBtn);

  // Initial stats
  updateGlobeStats(CITIES);

  // Render loop
  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);
    const elapsed = clock.getElapsedTime() * 1000;

    controls.update();
    globe.update();
    arcsLayer.update();
    hubLayer.update(elapsed);
    hover.update(citiesLayer);

    composer.render();
  }
  animate();

  // Resize handler
  const onResize = () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    handleResize(renderer, camera, container);
    resizeComposer(composer, w, h);
  };
  window.addEventListener('resize', onResize);
}

function updateGlobeStats(data) {
  const el = document.getElementById('globeStats');
  if (!el) return;
  const tot = data.reduce((a,c) => a + c.eventos, 0);
  const inv = data.reduce((a,c) => a + c.po, 0);
  el.innerHTML =
    `<div><div class="l">Cidades</div><div class="v">${NUM(data.length)}</div></div>` +
    `<div><div class="l">Eventos</div><div class="v">${NUM(tot)}</div></div>` +
    `<div><div class="l">Investimento</div><div class="v">${BRL(inv)}</div></div>`;
}

// ============================================================
//  3. ECHARTS — All analytical charts
// ============================================================
function initCharts() {
  const PAL = ['#eb0028','#d4a340','#22d3ee','#34d399','#a78bfa','#f97316','#0ea5e9','#ec4899','#84cc16','#8b5cf6'];
  const AX = {
    axisLine:{lineStyle:{color:'rgba(255,255,255,0.10)'}},
    axisLabel:{color:'#8b95a5',fontSize:11,fontFamily:'Inter'},
    splitLine:{lineStyle:{color:'rgba(255,255,255,0.04)'}},
    axisTick:{show:false}
  };
  const TT = {
    backgroundColor:'rgba(14,18,28,0.94)',borderColor:'rgba(255,255,255,0.08)',borderWidth:1,
    textStyle:{color:'#e8ecf1',fontSize:12,fontFamily:'Inter'},
    extraCssText:'box-shadow:0 8px 28px rgba(0,0,0,0.5);border-radius:11px;padding:10px 13px'
  };

  const charts = [];
  const mk = (el,opt) => { const c = echarts.init(document.getElementById(el),null,{renderer:'canvas'}); c.setOption(opt); charts.push(c); return c; };

  const hbar = (data,color) => ({
    grid:{left:'2%',right:'8%',top:14,bottom:10,containLabel:true},tooltip:{...TT,trigger:'axis',axisPointer:{type:'shadow'}},
    xAxis:{type:'value',...AX},yAxis:{type:'category',data:data.map(d=>d.k).reverse(),...AX,splitLine:{show:false}},
    series:[{type:'bar',data:data.map(d=>d.v).reverse(),barMaxWidth:16,itemStyle:{color:color||'#eb0028',borderRadius:[0,4,4,0]},
      label:{show:true,position:'right',color:'#8b95a5',fontSize:11,fontFamily:'Inter',fontWeight:600},animationDelay:i=>i*45}]
  });
  const donut = (data) => ({
    tooltip:{...TT,trigger:'item',formatter:p=>`${p.name}<br/><b>${NUM(p.value)}</b> eventos \u00b7 ${p.percent}%`},
    legend:{bottom:0,textStyle:{color:'#8b95a5',fontSize:11,fontFamily:'Inter'},itemWidth:9,itemHeight:9,icon:'circle'},
    color:PAL,
    series:[{type:'pie',radius:['48%','72%'],center:['50%','44%'],avoidLabelOverlap:true,
      itemStyle:{borderColor:'rgba(14,18,28,0.8)',borderWidth:2},label:{show:false},
      emphasis:{scale:true,scaleSize:6},data:data.map(d=>({name:d.k,value:d.v})),animationType:'scale'}]
  });
  const vbar = (data,color,log) => ({
    grid:{left:'2%',right:'3%',top:26,bottom:6,containLabel:true},tooltip:{...TT,trigger:'axis',axisPointer:{type:'shadow'}},
    xAxis:{type:'category',data:data.map(d=>d.k),...AX,axisLabel:{...AX.axisLabel,interval:0,rotate:data.length>4?22:0}},
    yAxis:{type:log?'log':'value',min:log?1:undefined,...AX},
    series:[{type:'bar',data:data.map(d=>d.v),barMaxWidth:44,itemStyle:{color:color||'#eb0028',borderRadius:[5,5,0,0]},
      label:{show:true,position:'top',color:'#8b95a5',fontSize:11,fontFamily:'Inter',fontWeight:600},animationDelay:i=>i*70}]
  });

  mk('cTA', hbar(TA.slice(0,12),'#eb0028'));
  mk('cFmt', donut(FORMATO));
  mk('cBU', donut(BU));
  mk('cCx', vbar(COMPLEXIDADE,'#d4a340'));
  mk('cTp', hbar(TIPO,'#22d3ee'));
  mk('cSt', vbar(STATUS_PGTO,'#34d399',true));

  // UF
  mk('cUF',{
    grid:{left:'2%',right:'12%',top:30,bottom:10,containLabel:true},
    tooltip:{...TT,trigger:'axis',axisPointer:{type:'shadow'}},
    legend:{top:0,right:0,textStyle:{color:'#8b95a5',fontSize:11,fontFamily:'Inter'},itemWidth:11,itemHeight:9,icon:'roundRect'},
    xAxis:{type:'value',...AX},yAxis:{type:'category',data:BY_UF.map(u=>u.uf).reverse(),...AX,splitLine:{show:false}},
    series:[
      {name:'Eventos',type:'bar',data:BY_UF.map(u=>u.eventos).reverse(),barMaxWidth:14,barGap:'30%',
        itemStyle:{color:'#22d3ee',borderRadius:[0,4,4,0]},label:{show:true,position:'right',color:'#8b95a5',fontSize:10,fontFamily:'Inter',fontWeight:600}},
      {name:'Valor (R$)',type:'bar',data:BY_UF.map(u=>u.valor).reverse(),barMaxWidth:14,
        itemStyle:{color:'#d4a340',borderRadius:[0,4,4,0]},label:{show:true,position:'right',color:'#8b95a5',fontSize:10,fontFamily:'Inter',fontWeight:600,formatter:p=>BRL(p.value)}}
    ]
  });

  // Annual
  mk('cAnual',{
    grid:{left:'2%',right:'2%',top:54,bottom:10,containLabel:true},
    tooltip:{...TT,trigger:'axis',axisPointer:{type:'shadow'},formatter:p=>p[0].axisValue+'<br/>'+p.map(s=>s.marker+s.seriesName+': <b>'+(s.seriesName==='Eventos'?NUM(s.value):BRLf(s.value))+'</b>').join('<br/>')},
    legend:{top:0,textStyle:{color:'#8b95a5',fontSize:11,fontFamily:'Inter'},itemWidth:11,itemHeight:9,icon:'roundRect'},
    xAxis:{type:'category',data:ANUAL.map(a=>'FY'+a.ano),...AX},
    yAxis:[{type:'value',...AX,axisLabel:{...AX.axisLabel,formatter:v=>BRL(v)}},{type:'value',...AX,splitLine:{show:false}}],
    series:[
      {name:'PO total',type:'bar',data:ANUAL.map(a=>a.po),barMaxWidth:26,itemStyle:{color:'#eb0028',borderRadius:[5,5,0,0]}},
      {name:'Pago',type:'bar',data:ANUAL.map(a=>a.pago),barMaxWidth:26,itemStyle:{color:'#d4a340',borderRadius:[5,5,0,0]}},
      {name:'Eventos',type:'line',yAxisIndex:1,data:ANUAL.map(a=>a.eventos),smooth:true,symbolSize:8,
        lineStyle:{width:2.6,color:'#22d3ee'},itemStyle:{color:'#22d3ee',borderColor:'rgba(14,18,28,0.8)',borderWidth:2},
        areaStyle:{color:new echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'rgba(34,211,238,.16)'},{offset:1,color:'rgba(34,211,238,0)'}])}}
    ]
  });

  mk('cPrazo', hbar(PRAZO.map(p=>({k:p.faixa,v:p.qtd})).reverse(),'#a78bfa'));

  // Timeline
  const anos = Object.keys(TIMELINE).map(Number).sort((a,b)=>a-b);
  const BUS = [...new Set(anos.flatMap(a=>TIMELINE[a].map(x=>x.bu)))];
  const maxTl = Math.max(...anos.flatMap(a=>TIMELINE[a].map(x=>x.valor)));
  mk('cTimeline',{
    baseOption:{
      timeline:{axisType:'category',data:anos.map(a=>'FY'+a),autoPlay:false,playInterval:1600,
        currentIndex:anos.length-1,left:'6%',right:'6%',bottom:6,
        label:{color:'#8b95a5',fontSize:11,fontFamily:'Inter',fontWeight:600},
        lineStyle:{color:'rgba(255,255,255,0.10)'},itemStyle:{color:'#4a5568'},
        checkpointStyle:{color:'#eb0028',borderColor:'rgba(235,0,40,.22)',borderWidth:6},
        controlStyle:{color:'#8b95a5',borderColor:'#8b95a5',itemSize:16},
        emphasis:{label:{color:'#eb0028'},itemStyle:{color:'#eb0028'}}},
      grid:{left:'2%',right:'10%',top:34,bottom:76,containLabel:true},
      tooltip:{...TT,trigger:'axis',axisPointer:{type:'shadow'},formatter:p=>p[0].name+'<br/><b>'+BRLf(p[0].value)+'</b>'},
      xAxis:{type:'value',max:maxTl*1.08,...AX,axisLabel:{...AX.axisLabel,formatter:v=>BRL(v)}},
      yAxis:{type:'category',data:[...BUS].reverse(),...AX,splitLine:{show:false}},
      series:[{type:'bar',barMaxWidth:26,itemStyle:{color:'#eb0028',borderRadius:[0,5,5,0]},
        label:{show:true,position:'right',color:'#8b95a5',fontSize:11,fontFamily:'Inter',fontWeight:600,formatter:p=>BRL(p.value)}}]
    },
    options:anos.map(a=>{
      const m = Object.fromEntries(TIMELINE[a].map(x=>[x.bu,x.valor]));
      return {title:{text:'FY'+a+' \u00b7 valor movimentado por BU',left:0,top:0,
        textStyle:{color:'#e8ecf1',fontSize:13.5,fontWeight:700,fontFamily:'Inter'}},
        series:[{data:[...BUS].reverse().map(b=>m[b]||0)}]};
    })
  });

  window.addEventListener('resize', () => charts.forEach(c => c.resize()));
}

// ============================================================
//  4. BOOT SEQUENCE
// ============================================================
async function boot() {
  initCharts();
  playEntrance();

  try {
    await initGlobe();
  } catch (err) {
    console.warn('[Globe] Init failed:', err);
  }
}

boot();
