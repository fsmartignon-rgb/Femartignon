import * as THREE from 'three';

/**
 * City markers rendered as instanced meshes for performance.
 * Each city gets a small sphere on the globe surface, sized and
 * colored proportionally to its event count.
 *
 * Uses InstancedMesh — single draw call for all markers.
 */

const DOMESTIC_COLOR = new THREE.Color(0x22d3ee); // cyan
const INTL_COLOR     = new THREE.Color(0xeb0028); // Takeda red
const HUB_COLOR      = new THREE.Color(0xd4a340); // gold

const MAX_CITIES = 200;
const dummy = new THREE.Object3D();

export class CitiesLayer {
  constructor(globe) {
    this.globe = globe;
    this.mesh = null;
    this.cityData = [];      // filtered data currently displayed
    this.allCityData = [];   // full dataset
  }

  init(cities) {
    this.allCityData = cities;

    const geometry = new THREE.SphereGeometry(0.4, 12, 8);
    const material = new THREE.MeshBasicMaterial({ toneMapped: false });

    this.mesh = new THREE.InstancedMesh(geometry, material, MAX_CITIES);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;
    this.mesh.userData.type = 'cities';

    this.globe.group.add(this.mesh);
    this.setCities(cities);

    return this;
  }

  /**
   * Update displayed cities (for filtering).
   */
  setCities(cities) {
    this.cityData = cities;
    const maxEv = Math.max(...cities.map((c) => c.eventos), 1);

    const colorAttr = new Float32Array(MAX_CITIES * 3);

    for (let i = 0; i < MAX_CITIES; i++) {
      if (i < cities.length) {
        const c = cities[i];
        const pos = this.globe.latLngToVector3(c.lat, c.lon, 0.004);
        const scale = 0.4 + 1.8 * Math.sqrt(c.eventos / maxEv);

        dummy.position.copy(pos);
        dummy.scale.setScalar(scale);
        dummy.lookAt(0, 0, 0); // orient outward
        dummy.updateMatrix();
        this.mesh.setMatrixAt(i, dummy.matrix);

        const color = c.pais === 'Brasil' ? DOMESTIC_COLOR : INTL_COLOR;
        colorAttr[i * 3]     = color.r;
        colorAttr[i * 3 + 1] = color.g;
        colorAttr[i * 3 + 2] = color.b;
      } else {
        // Hide unused instances by scaling to zero
        dummy.scale.setScalar(0);
        dummy.updateMatrix();
        this.mesh.setMatrixAt(i, dummy.matrix);
        colorAttr[i * 3] = colorAttr[i * 3 + 1] = colorAttr[i * 3 + 2] = 0;
      }
    }

    this.mesh.instanceMatrix.needsUpdate = true;
    this.mesh.geometry.setAttribute(
      'color',
      new THREE.InstancedBufferAttribute(colorAttr, 3),
    );
    this.mesh.material.vertexColors = true;
    this.mesh.count = cities.length;
  }

  /**
   * Get city data at a specific instance index.
   */
  getCityAt(index) {
    return this.cityData[index] || null;
  }
}
