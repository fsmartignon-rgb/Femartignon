import * as THREE from 'three';

/**
 * Hub markers: larger gold spheres with animated pulsing rings.
 * Three strategic hubs: Barcelona, Washington DC, Vienna.
 *
 * Each hub has:
 *   - A solid sphere marker
 *   - An expanding ring (pulse) that fades out
 */

const HUB_COLOR = 0xd4a340;

export class HubLayer {
  constructor(globe) {
    this.globe = globe;
    this.group = new THREE.Group();
    this.rings = []; // { mesh, phase }
  }

  init(hubs) {
    this.globe.group.add(this.group);

    const markerGeo = new THREE.SphereGeometry(1.0, 16, 12);
    const markerMat = new THREE.MeshBasicMaterial({
      color: HUB_COLOR,
      toneMapped: false,
    });

    const ringGeo = new THREE.RingGeometry(1.2, 1.6, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: HUB_COLOR,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide,
      depthWrite: false,
      toneMapped: false,
    });

    hubs.forEach((hub, i) => {
      const pos = this.globe.latLngToVector3(hub.lat, hub.lon, 0.01);

      // Solid marker
      const marker = new THREE.Mesh(markerGeo, markerMat);
      marker.position.copy(pos);
      marker.userData = { type: 'hub', data: hub };
      this.group.add(marker);

      // Pulse ring
      const ring = new THREE.Mesh(ringGeo, ringMat.clone());
      ring.position.copy(pos);
      ring.lookAt(0, 0, 0);
      this.group.add(ring);

      this.rings.push({
        mesh: ring,
        phase: (i / hubs.length) * Math.PI * 2, // stagger phases
      });
    });

    return this;
  }

  update(time) {
    for (const { mesh, phase } of this.rings) {
      const t = ((time * 0.001 + phase) % 2.5) / 2.5; // 2.5s cycle
      const scale = 1 + t * 3.5;
      const opacity = 0.6 * (1 - t);

      mesh.scale.setScalar(scale);
      mesh.material.opacity = Math.max(0, opacity);
    }
  }
}
