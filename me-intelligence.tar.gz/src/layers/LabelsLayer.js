import * as THREE from 'three';

/**
 * Sprite-based text labels that always face the camera.
 * Used for hub names (Barcelona, Washington DC, Vienna).
 *
 * Labels are rendered to a canvas and used as sprite textures
 * for crisp text at any camera angle.
 */

export class LabelsLayer {
  constructor(globe) {
    this.globe = globe;
    this.group = new THREE.Group();
    this.sprites = [];
  }

  init(hubs) {
    this.globe.group.add(this.group);

    for (const hub of hubs) {
      const sprite = this.createLabel(hub.nome);
      const pos = this.globe.latLngToVector3(hub.lat, hub.lon, 0.04);
      sprite.position.copy(pos);
      sprite.userData = { type: 'label', data: hub };
      this.group.add(sprite);
      this.sprites.push(sprite);
    }

    return this;
  }

  createLabel(text) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    const fontSize = 42;
    const padding = 24;
    ctx.font = `700 ${fontSize}px Inter, -apple-system, sans-serif`;
    const metrics = ctx.measureText(text);
    const textWidth = metrics.width;

    canvas.width = textWidth + padding * 2;
    canvas.height = fontSize + padding * 2;

    // Background pill
    ctx.fillStyle = 'rgba(6, 8, 12, 0.80)';
    const r = (fontSize + padding) / 2;
    this.roundRect(ctx, 0, 0, canvas.width, canvas.height, r);
    ctx.fill();

    // Border
    ctx.strokeStyle = 'rgba(212, 163, 64, 0.35)';
    ctx.lineWidth = 2;
    this.roundRect(ctx, 1, 1, canvas.width - 2, canvas.height - 2, r - 1);
    ctx.stroke();

    // Text
    ctx.font = `700 ${fontSize}px Inter, -apple-system, sans-serif`;
    ctx.fillStyle = '#d4a340';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, canvas.width / 2, canvas.height / 2);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;

    const material = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      sizeAttenuation: true,
      toneMapped: false,
    });

    const sprite = new THREE.Sprite(material);
    const aspect = canvas.width / canvas.height;
    sprite.scale.set(5 * aspect, 5, 1);

    return sprite;
  }

  roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
}
