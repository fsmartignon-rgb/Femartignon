import * as THREE from 'three';

/**
 * Animated arc lines from São Paulo (hub) to each destination.
 *
 * Each arc is a CubicBezierCurve3 with a control point lifted above the
 * globe surface. The dash offset is animated each frame for the traveling
 * pulse effect.
 *
 * Colors: cyan for domestic, red for international.
 */

const HUB = { lat: -23.5505, lng: -46.6333 };
const ARC_SEGMENTS = 64;
const DOMESTIC_COLOR = 0x22d3ee;
const INTL_COLOR = 0xeb0028;

export class ArcsLayer {
  constructor(globe) {
    this.globe = globe;
    this.arcs = [];  // { line, speed }
    this.group = new THREE.Group();
  }

  init(cities) {
    this.globe.group.add(this.group);
    this.setArcs(cities);
    return this;
  }

  setArcs(cities) {
    // Clean up existing arcs
    this.arcs.forEach(({ line }) => this.group.remove(line));
    this.arcs = [];

    const maxEv = Math.max(...cities.map((c) => c.eventos), 1);
    const hubPos = this.globe.latLngToVector3(HUB.lat, HUB.lng, 0);

    for (const city of cities) {
      // Skip the hub itself
      if (city.lat === HUB.lat && city.lon === HUB.lng) continue;

      const destPos = this.globe.latLngToVector3(city.lat, city.lon, 0);

      // Midpoint lifted above globe for the arc curve
      const mid = new THREE.Vector3().addVectors(hubPos, destPos).multiplyScalar(0.5);
      const dist = hubPos.distanceTo(destPos);
      const liftHeight = 1 + dist * 0.22;
      mid.normalize().multiplyScalar(this.globe.radius + liftHeight);

      // Control points for cubic bezier
      const cp1 = new THREE.Vector3().lerpVectors(hubPos, mid, 0.5);
      cp1.normalize().multiplyScalar(this.globe.radius + liftHeight * 0.6);
      const cp2 = new THREE.Vector3().lerpVectors(mid, destPos, 0.5);
      cp2.normalize().multiplyScalar(this.globe.radius + liftHeight * 0.6);

      const curve = new THREE.CubicBezierCurve3(hubPos, cp1, cp2, destPos);
      const points = curve.getPoints(ARC_SEGMENTS);
      const geometry = new THREE.BufferGeometry().setFromPoints(points);

      const isDomestic = city.pais === 'Brasil';
      const intensity = Math.sqrt(city.eventos / maxEv);

      const material = new THREE.LineDashedMaterial({
        color: isDomestic ? DOMESTIC_COLOR : INTL_COLOR,
        transparent: true,
        opacity: 0.25 + 0.45 * intensity,
        dashSize: 2,
        gapSize: 1.5,
        linewidth: 1,
        depthWrite: false,
        toneMapped: false,
      });

      const line = new THREE.Line(geometry, material);
      line.computeLineDistances();
      this.group.add(line);

      // Animation speed varies per arc
      const speed = 0.05 + 0.03 * Math.random();
      this.arcs.push({ line, material, speed });
    }
  }

  update() {
    for (const arc of this.arcs) {
      arc.material.dashOffset -= arc.speed;
    }
  }
}
