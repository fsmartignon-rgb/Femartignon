import gsap from 'gsap';

/**
 * Smooth camera transitions using GSAP.
 * Converts lat/lng/altitude targets to 3D positions and
 * tweens the camera with easing + damping.
 */
export class CameraFlight {
  constructor(camera, controls, globeRadius) {
    this.camera = camera;
    this.controls = controls;
    this.globeRadius = globeRadius;
    this.isAnimating = false;
  }

  /**
   * Fly to a lat/lng position at a given altitude.
   * @param {{ lat: number, lng: number, alt: number }} target
   * @param {number} duration — seconds
   */
  flyTo(target, duration = 2.0) {
    const { lat, lng, alt } = target;
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    const r = alt || this.globeRadius * 3;

    const destX = -r * Math.sin(phi) * Math.cos(theta);
    const destY = r * Math.cos(phi);
    const destZ = r * Math.sin(phi) * Math.sin(theta);

    // Pause auto-rotate during flight
    const wasAutoRotating = this.controls.autoRotate;
    this.controls.autoRotate = false;
    this.isAnimating = true;

    gsap.to(this.camera.position, {
      x: destX,
      y: destY,
      z: destZ,
      duration,
      ease: 'power3.inOut',
      onUpdate: () => {
        this.camera.lookAt(0, 0, 0);
        this.controls.update();
      },
      onComplete: () => {
        this.controls.autoRotate = wasAutoRotating;
        this.isAnimating = false;
      },
    });
  }

  /**
   * Reset to the default global view.
   */
  reset(duration = 2.0) {
    this.flyTo({ lat: 20, lng: -20, alt: 300 }, duration);
    this.controls.autoRotate = true;
  }
}
