import gsap from 'gsap';

/**
 * Dashboard entrance animation timeline.
 * Staggered reveals for hero, KPIs, globe, and chart sections.
 */
export function playEntrance() {
  const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

  tl.from('.mark', { opacity: 0, y: 20, duration: 0.6 }, 0.1)
    .from('.hero h1', { opacity: 0, y: 30, duration: 0.7 }, 0.2)
    .from('.hero .lede', { opacity: 0, y: 20, duration: 0.6 }, 0.35)
    .from('.metaline span', { opacity: 0, y: 12, duration: 0.4, stagger: 0.05 }, 0.5)
    .from('.kpi', { opacity: 0, y: 24, duration: 0.5, stagger: 0.07 }, 0.7)
    .from('.ticker', { opacity: 0, y: 14, duration: 0.5 }, 0.9)
    .from('.globe-section', { opacity: 0, y: 30, duration: 0.8 }, 1.0);

  return tl;
}
