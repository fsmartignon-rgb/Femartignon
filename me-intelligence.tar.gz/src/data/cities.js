/**
 * M&E event data — Single Source of Truth.
 * Extracted from CONSOLIDADA dataset (FY2021–FY2027).
 */

export const META = {
  eventos: 739, paises: 26, pagamentos: 2568,
  valor_total: 188691608.46, pago: 173335191.89,
  outstanding: 12516016.51, complexidade_alta: 515,
  fornecedores: 323, periodo: 'FY2021\u2013FY2027',
};

export const TICKER = [
  {pais:'Brasil',n:567},{pais:'EUA',n:55},{pais:'Espanha',n:17},
  {pais:'Alemanha',n:10},{pais:'\u00c1ustria',n:7},{pais:'Argentina',n:6},
  {pais:'Holanda',n:6},{pais:'Portugal',n:5},{pais:'It\u00e1lia',n:5},
  {pais:'Su\u00e9cia',n:4},{pais:'Reino Unido',n:3},{pais:'Dinamarca',n:3},
  {pais:'Su\u00ed\u00e7a',n:3},{pais:'Finl\u00e2ndia',n:3},{pais:'Gr\u00e9cia',n:2},
  {pais:'Fran\u00e7a',n:2},{pais:'Canad\u00e1',n:2},{pais:'B\u00e9lgica',n:1},
  {pais:'Cingapura',n:1},{pais:'Rep\u00fablica Tcheca',n:1},{pais:'Taiwan',n:1},
  {pais:'Mal\u00e1sia',n:1},{pais:'Turquia',n:1},{pais:'Europa',n:1},
  {pais:'Filipinas',n:1},{pais:'M\u00e9xico',n:1},
];

export const CITIES = [
  {cidade:'S\u00e3o Paulo',pais:'Brasil',lat:-23.5505,lon:-46.6333,eventos:298,po:50726427.63,pago:47549672.35,cont:'Am\u00e9rica do Sul'},
  {cidade:'Rio de Janeiro',pais:'Brasil',lat:-22.9068,lon:-43.1729,eventos:29,po:2054834.78,pago:2033845.09,cont:'Am\u00e9rica do Sul'},
  {cidade:'Fortaleza',pais:'Brasil',lat:-3.7319,lon:-38.5267,eventos:13,po:2364718.13,pago:1499157.26,cont:'Am\u00e9rica do Sul'},
  {cidade:'Campinas',pais:'Brasil',lat:-22.9099,lon:-47.0626,eventos:12,po:0,pago:0,cont:'Am\u00e9rica do Sul'},
  {cidade:'Barcelona',pais:'Espanha',lat:41.3874,lon:2.1686,eventos:10,po:513176.52,pago:420267.76,cont:'Europa'},
  {cidade:'Curitiba',pais:'Brasil',lat:-25.4284,lon:-49.2733,eventos:9,po:841271.53,pago:841271.53,cont:'Am\u00e9rica do Sul'},
  {cidade:'Washington',pais:'EUA',lat:38.9072,lon:-77.0369,eventos:9,po:8604501.63,pago:5939387.53,cont:'Am\u00e9rica do Norte'},
  {cidade:'San Diego',pais:'EUA',lat:32.7157,lon:-117.1611,eventos:8,po:2009691.54,pago:1973159.57,cont:'Am\u00e9rica do Norte'},
  {cidade:'Chicago',pais:'EUA',lat:41.8781,lon:-87.6298,eventos:7,po:62687.95,pago:0,cont:'Am\u00e9rica do Norte'},
  {cidade:'Viena',pais:'\u00c1ustria',lat:48.2082,lon:16.3738,eventos:7,po:1111981.99,pago:920191.74,cont:'Europa'},
  {cidade:'Florian\u00f3polis',pais:'Brasil',lat:-27.5954,lon:-48.548,eventos:6,po:36171.45,pago:36171.45,cont:'Am\u00e9rica do Sul'},
  {cidade:'New Orleans',pais:'EUA',lat:29.9511,lon:-90.0715,eventos:6,po:797006.78,pago:651242.49,cont:'Am\u00e9rica do Norte'},
  {cidade:'Buenos Aires',pais:'Argentina',lat:-34.6037,lon:-58.3816,eventos:6,po:0,pago:0,cont:'Am\u00e9rica do Sul'},
  {cidade:'Madrid',pais:'Espanha',lat:40.4168,lon:-3.7038,eventos:6,po:621391.06,pago:262361.18,cont:'Europa'},
  {cidade:'Belo Horizonte',pais:'Brasil',lat:-19.9167,lon:-43.9345,eventos:5,po:786868.73,pago:786868.73,cont:'Am\u00e9rica do Sul'},
  {cidade:'Salvador',pais:'Brasil',lat:-12.9777,lon:-38.5016,eventos:5,po:4081878.63,pago:4047369.34,cont:'Am\u00e9rica do Sul'},
  {cidade:'Amsterd\u00e3',pais:'Holanda',lat:52.3676,lon:4.9041,eventos:5,po:62068.16,pago:62068.16,cont:'Europa'},
  {cidade:'Lisboa',pais:'Portugal',lat:38.7223,lon:-9.1393,eventos:5,po:26243.75,pago:26243.75,cont:'Europa'},
  {cidade:'Bel\u00e9m',pais:'Brasil',lat:-1.4558,lon:-48.5044,eventos:4,po:352545.08,pago:350406.77,cont:'Am\u00e9rica do Sul'},
  {cidade:'Porto Alegre',pais:'Brasil',lat:-30.0346,lon:-51.2177,eventos:4,po:377928.00,pago:377928.00,cont:'Am\u00e9rica do Sul'},
  {cidade:'Estocolmo',pais:'Su\u00e9cia',lat:59.3293,lon:18.0686,eventos:4,po:2898736.27,pago:2858754.99,cont:'Europa'},
  {cidade:'Berlim',pais:'Alemanha',lat:52.52,lon:13.405,eventos:4,po:2962709.03,pago:2610191.38,cont:'Europa'},
  {cidade:'Natal',pais:'Brasil',lat:-5.7945,lon:-35.211,eventos:3,po:595829.87,pago:595829.87,cont:'Am\u00e9rica do Sul'},
  {cidade:'Recife',pais:'Brasil',lat:-8.0476,lon:-34.877,eventos:3,po:973794.95,pago:973794.95,cont:'Am\u00e9rica do Sul'},
  {cidade:'Boston',pais:'EUA',lat:42.3601,lon:-71.0589,eventos:3,po:431169.80,pago:342164.23,cont:'Am\u00e9rica do Norte'},
  {cidade:'Copenhague',pais:'Dinamarca',lat:55.6761,lon:12.5683,eventos:3,po:3102598.41,pago:3102598.41,cont:'Europa'},
  {cidade:'Hamburgo',pais:'Alemanha',lat:53.5511,lon:9.9937,eventos:3,po:68817.98,pago:68817.98,cont:'Europa'},
  {cidade:'Helsinki',pais:'Finl\u00e2ndia',lat:60.1699,lon:24.9384,eventos:3,po:592599.93,pago:592430.20,cont:'Europa'},
  {cidade:'Campo Grande',pais:'Brasil',lat:-20.4697,lon:-54.6201,eventos:2,po:310276.58,pago:310276.58,cont:'Am\u00e9rica do Sul'},
  {cidade:'Manaus',pais:'Brasil',lat:-3.119,lon:-60.0217,eventos:2,po:0,pago:0,cont:'Am\u00e9rica do Sul'},
  {cidade:'Atenas',pais:'Gr\u00e9cia',lat:37.9838,lon:23.7275,eventos:2,po:0,pago:0,cont:'Europa'},
  {cidade:'San Antonio',pais:'EUA',lat:29.4241,lon:-98.4936,eventos:2,po:171319.38,pago:165418.99,cont:'Am\u00e9rica do Norte'},
  {cidade:'Paris',pais:'Fran\u00e7a',lat:48.8566,lon:2.3522,eventos:2,po:0,pago:0,cont:'Europa'},
  {cidade:'Montreal',pais:'Canad\u00e1',lat:45.5017,lon:-73.5673,eventos:2,po:20189.32,pago:20189.32,cont:'Am\u00e9rica do Norte'},
  {cidade:'Lugano',pais:'Su\u00ed\u00e7a',lat:46.0037,lon:8.9511,eventos:2,po:686678.76,pago:686678.76,cont:'Europa'},
  {cidade:'Nashville',pais:'EUA',lat:36.1627,lon:-86.7816,eventos:2,po:34314.43,pago:34314.43,cont:'Am\u00e9rica do Norte'},
  {cidade:'Orlando',pais:'EUA',lat:28.5383,lon:-81.3792,eventos:2,po:1159110.02,pago:1141170.83,cont:'Am\u00e9rica do Norte'},
  {cidade:'Mil\u00e3o',pais:'It\u00e1lia',lat:45.4642,lon:9.19,eventos:2,po:257180.17,pago:257180.17,cont:'Europa'},
  {cidade:'Col\u00f4nia',pais:'Alemanha',lat:50.9375,lon:6.9603,eventos:2,po:80057.09,pago:0,cont:'Europa'},
  {cidade:'Ribeir\u00e3o Preto',pais:'Brasil',lat:-21.1775,lon:-47.8103,eventos:1,po:0,pago:0,cont:'Am\u00e9rica do Sul'},
  {cidade:'Atlanta',pais:'EUA',lat:33.749,lon:-84.388,eventos:1,po:0,pago:0,cont:'GLOBAL'},
  {cidade:'Bruxelas',pais:'B\u00e9lgica',lat:50.8503,lon:4.3517,eventos:1,po:0,pago:0,cont:'Europa'},
  {cidade:'Praga',pais:'Rep\u00fablica Tcheca',lat:50.0755,lon:14.4378,eventos:1,po:0,pago:0,cont:'Europa'},
  {cidade:'Londres',pais:'Reino Unido',lat:51.5074,lon:-0.1278,eventos:1,po:0,pago:0,cont:'Europa'},
  {cidade:'Phoenix',pais:'EUA',lat:33.4484,lon:-112.074,eventos:1,po:0,pago:0,cont:'Am\u00e9rica do Norte'},
  {cidade:'Taipei',pais:'Taiwan',lat:25.033,lon:121.5654,eventos:1,po:0,pago:0,cont:'Am\u00e9rica do Sul'},
  {cidade:'Kuala Lumpur',pais:'Mal\u00e1sia',lat:3.139,lon:101.6869,eventos:1,po:339620.46,pago:313378.15,cont:'\u00c1sia'},
  {cidade:'Istambul',pais:'Turquia',lat:41.0082,lon:28.9784,eventos:1,po:131430.49,pago:131430.49,cont:'Europa'},
  {cidade:'Los Angeles',pais:'EUA',lat:34.0522,lon:-118.2437,eventos:1,po:0,pago:0,cont:'Am\u00e9rica do Norte'},
  {cidade:'Denver',pais:'EUA',lat:39.7392,lon:-104.9903,eventos:1,po:0,pago:0,cont:'Am\u00e9rica do Norte'},
  {cidade:'Manila',pais:'Filipinas',lat:14.5995,lon:120.9842,eventos:1,po:161330.77,pago:160370.45,cont:'\u00c1sia'},
];

export const HUBS = [
  { nome: 'Barcelona',     lat: 41.3874, lon: 2.1686 },
  { nome: 'Washington DC', lat: 38.9072, lon: -77.0369 },
  { nome: 'Viena',         lat: 48.2082, lon: 16.3738 },
];

export const BY_UF = [
  {uf:'SP',eventos:311,valor:50726427.63},{uf:'RJ',eventos:29,valor:2054834.78},
  {uf:'CE',eventos:13,valor:2364718.13},{uf:'PR',eventos:9,valor:841271.53},
  {uf:'SC',eventos:6,valor:36171.45},{uf:'MG',eventos:5,valor:786868.73},
  {uf:'BA',eventos:5,valor:4081878.63},{uf:'PA',eventos:4,valor:352545.08},
  {uf:'RS',eventos:4,valor:377928.00},{uf:'RN',eventos:3,valor:595829.87},
  {uf:'PE',eventos:3,valor:973794.95},{uf:'MS',eventos:2,valor:310276.58},
  {uf:'AM',eventos:2,valor:0},
];

export const TA = [{k:'Doen\u00e7as-Raras',v:175},{k:'Neuroci\u00eancias',v:98},{k:'Oncologia',v:84},{k:'Gastro-imuno',v:80},{k:'Gastro-retail',v:77},{k:'Vacinas',v:68},{k:'Gastro Rare',v:58},{k:'Onco-Hemato',v:32},{k:'Hematologia',v:29},{k:'Market Access',v:22},{k:'Onco-S\u00f3lidos',v:15},{k:'Imunologia',v:1}];
export const FORMATO = [{k:'PRESENCIAL',v:457},{k:'ONLINE',v:246},{k:'H\u00cdBRIDO',v:36}];
export const BU = [{k:'Specialty & Vacinas',v:268},{k:'Doen\u00e7as-Raras & Oncologia',v:250},{k:'Medical Affairs',v:199},{k:'Market Access',v:22}];
export const COMPLEXIDADE = [{k:'ALTA',v:515},{k:'M\u00c9DIA',v:175},{k:'BAIXA',v:25}];
export const TIPO = [{k:'TOME',v:243},{k:'CONGRESSO NACIONAL',v:199},{k:'APOIO CIENT\u00cdFICO INTERNACIONAL',v:170},{k:'CONGRESSO REGIONAL',v:106},{k:'SUBS\u00cdDIO',v:9},{k:'TUTORIAL',v:7},{k:'APOIO CIENT\u00cdFICO',v:5}];
export const STATUS_PGTO = [{k:'PAGO',v:2262},{k:'CREDITO',v:115},{k:'PENDENTE',v:95},{k:'ANDAMENTO',v:52},{k:'SOLICITADO',v:42},{k:'CANCELADO',v:2}];
export const ANUAL = [{ano:2022,po:8617.4,pago:8617.4,eventos:147},{ano:2023,po:38402269.32,pago:36393624.86,eventos:129},{ano:2024,po:58662818.69,pago:57013526.88,eventos:152},{ano:2025,po:58957997.55,pago:56401780.67,eventos:93},{ano:2026,po:32659905.50,pago:23517642.08,eventos:67}];

export const TIMELINE = {
  2022:[{bu:'Medical Affairs',valor:8617.4}],
  2023:[{bu:'Specialty & Vacinas',valor:18364554.02},{bu:'Medical Affairs',valor:13772315.94},{bu:'Doen\u00e7as-Raras & Oncologia',valor:5340755.05},{bu:'Market Access',valor:860909.21},{bu:'Corporativo',valor:63735.10}],
  2024:[{bu:'Medical Affairs',valor:19738067.69},{bu:'Specialty & Vacinas',valor:19524425.94},{bu:'Doen\u00e7as-Raras & Oncologia',valor:10416782.97},{bu:'Corporativo',valor:8288319.29},{bu:'Market Access',valor:695222.80}],
  2025:[{bu:'Specialty & Vacinas',valor:20903084.02},{bu:'Medical Affairs',valor:16535548.18},{bu:'Doen\u00e7as-Raras & Oncologia',valor:11764274.29},{bu:'Corporativo',valor:8696016.65},{bu:'Market Access',valor:1059074.41}],
  2026:[{bu:'Specialty & Vacinas',valor:9033831.39},{bu:'Medical Affairs',valor:8620971.73},{bu:'Corporativo',valor:7575197.94},{bu:'Doen\u00e7as-Raras & Oncologia',valor:7364904.44},{bu:'Market Access',valor:65000}],
};

export const FORNECEDORES = [
  {nome:'OPUS VIAGENS E EVENTOS LTDA EPP',valor:71679925.21,pgtos:1065},
  {nome:'INCENTIVARE ORG EVENTOS DMB BRASIL LTDA',valor:49142382.59,pgtos:603},
  {nome:'CASA DA VILA HUB DE COMUNICA\u00c7\u00c3O LTD',valor:24315083.51,pgtos:297},
  {nome:'BOUTIQUE GOURMET GASTRONOMIA E EVENTOS L',valor:5769075.03,pgtos:85},
  {nome:'POLI DESIGN PROJ PROMO EMPREENDIMENTOS',valor:5014246.02,pgtos:88},
  {nome:'PJK EVENTOS LTDA',valor:4728775.14,pgtos:22},
  {nome:'G.E.D.I.I.B.',valor:1978112,pgtos:8},
  {nome:'INSTITUTO DE CIENCIAS INTE CULTURA E EVENTOS LTDA',valor:1791400.34,pgtos:6},
  {nome:'GERA\u00c7\u00c3O MAIS CRIATIVA LTDA',valor:1251546.15,pgtos:4},
  {nome:'ASSOCIACAO BRASILEIRA DE IMUNIZACOES SBIM',valor:1234000,pgtos:14},
  {nome:'SOBEDSOC BRAS DE ENDOSCOPIA CAP SP',valor:1150000,pgtos:2},
  {nome:'ABHH',valor:1142400,pgtos:9},
];

export const PRAZO = [
  {faixa:'Antecipado',qtd:113},{faixa:'0\u201330 dias',qtd:730},
  {faixa:'31\u201360 dias',qtd:335},{faixa:'61\u201390 dias',qtd:1089},
  {faixa:'91\u2013120 dias',qtd:181},{faixa:'120+ dias',qtd:16},
];
