import * as THREE from 'three';

/**
 * Star field background.
 * Uses a large inverted sphere with an emissive star texture.
 * The sphere is static and sits behind everything.
 */
export class Stars {
  constructor() {
    this.mesh = null;
  }

  async init(textureLoader) {
    let starTexture;
    try {
      starTexture = await textureLoader.loadAsync('/textures/stars.png');
    } catch {
      // Fallback: procedural stars via particles
      return this.createProceduralStars();
    }

    starTexture.colorSpace = THREE.SRGBColorSpace;

    const geometry = new THREE.SphereGeometry(900, 32, 16);
    const material = new THREE.MeshBasicMaterial({
      map: starTexture,
      side: THREE.BackSide,
      depthWrite: false,
    });

    this.mesh = new THREE.Mesh(geometry, material);
    return this.mesh;
  }

  /** Generates a particle-based star field as fallback. */
  createProceduralStars() {
    const count = 6000;
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // Random point on a large sphere
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 800 + Math.random() * 100;
      positions[i * 3]     = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
      sizes[i] = 0.3 + Math.random() * 1.2;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.8,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
    });

    this.mesh = new THREE.Points(geometry, material);
    return this.mesh;
  }
}
