import * as THREE from 'three';
import { EARTH_RADIUS } from './Earth.js';

/**
 * Atmosphere glow effect using a Fresnel-based shader.
 * A slightly larger transparent sphere that glows strongest at the edges
 * (where the view is tangent to the surface), simulating atmospheric scattering.
 */

const vertexShader = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorldPosition;

  void main() {
    vNormal = normalize(normalMatrix * normal);
    vWorldPosition = (modelMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const fragmentShader = /* glsl */ `
  uniform vec3 glowColor;
  uniform float intensity;
  uniform float power;
  uniform vec3 sunDirection;

  varying vec3 vNormal;
  varying vec3 vWorldPosition;

  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorldPosition);
    float fresnel = pow(1.0 - abs(dot(vNormal, viewDir)), power);

    // Sun-side brightening
    float sunFactor = 0.5 + 0.5 * dot(vNormal, sunDirection);

    float alpha = fresnel * intensity * (0.6 + 0.4 * sunFactor);
    vec3 color = glowColor * (0.8 + 0.2 * sunFactor);

    gl_FragColor = vec4(color, alpha);
  }
`;

export class Atmosphere {
  constructor() {
    this.mesh = null;
  }

  init(sunDirection) {
    const geometry = new THREE.SphereGeometry(EARTH_RADIUS * 1.06, 64, 32);
    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        glowColor:    { value: new THREE.Color(0x4488cc) },
        intensity:    { value: 0.7 },
        power:        { value: 3.5 },
        sunDirection: { value: sunDirection },
      },
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.mesh = new THREE.Mesh(geometry, material);
    return this.mesh;
  }
}
