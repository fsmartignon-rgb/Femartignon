import * as THREE from 'three';
import { EARTH_RADIUS } from './Earth.js';

/**
 * Cloud layer: a slightly larger sphere with an alpha-mapped cloud texture.
 * Rotates independently at a slower speed for parallax depth.
 */
export class Clouds {
  constructor() {
    this.mesh = null;
    this.speed = 0.0004; // rad per frame (~0.02°/frame at 60fps)
  }

  async init(textureLoader) {
    let cloudTexture;
    try {
      cloudTexture = await textureLoader.loadAsync('/textures/clouds.png');
    } catch {
      // Clouds are optional — skip silently if texture is missing
      return null;
    }

    cloudTexture.anisotropy = 8;

    const geometry = new THREE.SphereGeometry(EARTH_RADIUS * 1.012, 96, 48);
    const material = new THREE.MeshPhongMaterial({
      map: cloudTexture,
      alphaMap: cloudTexture,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
      side: THREE.DoubleSide,
    });

    this.mesh = new THREE.Mesh(geometry, material);
    return this.mesh;
  }

  update() {
    if (this.mesh) {
      this.mesh.rotation.y += this.speed;
    }
  }
}
