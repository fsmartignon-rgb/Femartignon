import * as THREE from 'three';

const EARTH_RADIUS = 60;

/**
 * Earth sphere with custom day/night shader.
 * The fragment shader blends the day and night textures based on
 * the dot product between the surface normal and the sun direction.
 * The night side reveals city lights. The transition zone (terminator)
 * is smoothly blended for a realistic look.
 */

const vertexShader = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vWorldPosition;

  void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vWorldPosition = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`;

const fragmentShader = /* glsl */ `
  uniform sampler2D dayTexture;
  uniform sampler2D nightTexture;
  uniform sampler2D bumpTexture;
  uniform sampler2D specularTexture;
  uniform vec3 sunDirection;

  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vWorldPosition;

  void main() {
    vec3 dayColor   = texture2D(dayTexture, vUv).rgb;
    vec3 nightColor = texture2D(nightTexture, vUv).rgb;
    float specMask  = texture2D(specularTexture, vUv).r;

    // Day/night blending based on sun angle
    float cosAngle = dot(vNormal, sunDirection);
    float dayFactor = smoothstep(-0.12, 0.18, cosAngle);

    // Boost city lights on dark side
    vec3 nightBoosted = nightColor * 2.2;

    // Blend day and night
    vec3 color = mix(nightBoosted, dayColor, dayFactor);

    // Diffuse lighting for day side
    float diffuse = max(0.0, cosAngle);
    color = mix(color, dayColor * (0.3 + 0.7 * diffuse), dayFactor);

    // Specular highlight on oceans (day side only)
    vec3 viewDir = normalize(cameraPosition - vWorldPosition);
    vec3 halfDir = normalize(sunDirection + viewDir);
    float spec = pow(max(dot(vNormal, halfDir), 0.0), 64.0) * specMask * dayFactor;
    color += vec3(1.0, 0.95, 0.88) * spec * 0.5;

    gl_FragColor = vec4(color, 1.0);
  }
`;

export class Earth {
  constructor() {
    this.mesh = null;
    this.material = null;
    this.radius = EARTH_RADIUS;
  }

  async init(textureLoader, sunDirection) {
    const [day, night, bump, specular] = await Promise.all([
      textureLoader.loadAsync('/textures/earth_day.jpg'),
      textureLoader.loadAsync('/textures/earth_night.jpg'),
      textureLoader.loadAsync('/textures/earth_bump.png'),
      textureLoader.loadAsync('/textures/earth_water.png').catch(() => {
        // Specular map is optional — generate a black fallback
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 4;
        return new THREE.CanvasTexture(canvas);
      }),
    ]);

    // Enable anisotropic filtering for quality at grazing angles
    const maxAniso = 16;
    [day, night, bump, specular].forEach((t) => {
      t.anisotropy = maxAniso;
      t.colorSpace = THREE.SRGBColorSpace;
      t.generateMipmaps = true;
      t.minFilter = THREE.LinearMipmapLinearFilter;
    });
    // Bump and specular are data textures — linear space
    bump.colorSpace = THREE.LinearSRGBColorSpace;
    specular.colorSpace = THREE.LinearSRGBColorSpace;

    this.material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        dayTexture:      { value: day },
        nightTexture:    { value: night },
        bumpTexture:     { value: bump },
        specularTexture: { value: specular },
        sunDirection:    { value: sunDirection },
      },
    });

    const geometry = new THREE.SphereGeometry(this.radius, 128, 64);
    this.mesh = new THREE.Mesh(geometry, this.material);
    this.mesh.rotation.y = -Math.PI / 2; // prime meridian at front

    return this.mesh;
  }

  updateSunDirection(dir) {
    if (this.material) {
      this.material.uniforms.sunDirection.value.copy(dir);
    }
  }
}

export { EARTH_RADIUS };
