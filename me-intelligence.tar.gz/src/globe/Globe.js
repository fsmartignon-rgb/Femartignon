import * as THREE from 'three';
import { Earth, EARTH_RADIUS } from './Earth.js';
import { Atmosphere } from './Atmosphere.js';
import { Clouds } from './Clouds.js';
import { Stars } from './Stars.js';

/**
 * Globe orchestrator.
 * Owns the Three.js Group that contains Earth, Atmosphere, Clouds, Stars.
 * Provides update() for the render loop and coordinate conversion helpers.
 */
export class Globe {
  constructor() {
    this.group = new THREE.Group();
    this.earth = new Earth();
    this.atmosphere = new Atmosphere();
    this.clouds = new Clouds();
    this.stars = new Stars();
    this.radius = EARTH_RADIUS;
  }

  async init(scene, sunDirection, textureLoader) {
    const earthMesh = await this.earth.init(textureLoader, sunDirection);
    this.group.add(earthMesh);

    const atmoMesh = this.atmosphere.init(sunDirection);
    this.group.add(atmoMesh);

    const cloudMesh = await this.clouds.init(textureLoader);
    if (cloudMesh) this.group.add(cloudMesh);

    const starMesh = await this.stars.init(textureLoader);
    if (starMesh) scene.add(starMesh); // stars are scene-level, not globe-level

    scene.add(this.group);
    return this;
  }

  update() {
    this.clouds.update();
  }

  /**
   * Convert lat/lng (degrees) to a 3D position on the globe surface.
   * @param {number} lat - Latitude in degrees (-90 to 90)
   * @param {number} lng - Longitude in degrees (-180 to 180)
   * @param {number} altitude - Altitude above surface as fraction of radius (0 = surface)
   * @returns {THREE.Vector3}
   */
  latLngToVector3(lat, lng, altitude = 0) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    const r = this.radius * (1 + altitude);

    return new THREE.Vector3(
      -r * Math.sin(phi) * Math.cos(theta),
       r * Math.cos(phi),
       r * Math.sin(phi) * Math.sin(theta),
    );
  }

  /**
   * Convert a 3D position back to lat/lng.
   * @param {THREE.Vector3} pos
   * @returns {{ lat: number, lng: number }}
   */
  vector3ToLatLng(pos) {
    const r = pos.length();
    const lat = 90 - Math.acos(pos.y / r) * (180 / Math.PI);
    const lng = ((Math.atan2(pos.z, -pos.x) * 180) / Math.PI) - 180;
    return { lat, lng: ((lng + 540) % 360) - 180 };
  }
}
