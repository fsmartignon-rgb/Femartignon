import * as THREE from 'three';

/**
 * Creates a perspective camera positioned for globe viewing.
 * FOV 45° gives a slightly telephoto look — less distortion, more cinematic.
 */
export function createCamera(aspect = 16 / 9) {
  const camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 2000);
  camera.position.set(0, 0, 300);
  return camera;
}
