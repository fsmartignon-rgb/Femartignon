import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

/**
 * Sets up the post-processing pipeline:
 *   RenderPass → UnrealBloom → SMAA → OutputPass
 *
 * Bloom gives the atmosphere and city lights their glow.
 * SMAA smooths edges without the performance cost of MSAA.
 */
export function createComposer(renderer, scene, camera) {
  const size = renderer.getSize(new THREE.Vector2());
  const composer = new EffectComposer(renderer);

  // Base render
  composer.addPass(new RenderPass(scene, camera));

  // Bloom — subtle, focused on bright emissives
  const bloom = new UnrealBloomPass(size, 0.6, 0.4, 0.85);
  bloom.threshold = 0.82;
  bloom.strength = 0.55;
  bloom.radius = 0.35;
  composer.addPass(bloom);

  // Anti-aliasing
  const smaa = new SMAAPass(size.x, size.y);
  composer.addPass(smaa);

  // Output (tone mapping + color space)
  composer.addPass(new OutputPass());

  return { composer, bloom };
}

/**
 * Resize the composer to match new dimensions.
 */
export function resizeComposer(composer, width, height) {
  composer.setSize(width, height);
}
