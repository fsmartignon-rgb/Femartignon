import * as THREE from 'three';

/**
 * Creates and configures the WebGL renderer.
 * ACES Filmic tone mapping, proper pixel ratio, alpha for compositing.
 */
export function createRenderer(canvas) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
  });

  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = false; // no shadows needed for globe

  return renderer;
}

/**
 * Handles resize for renderer + camera.
 */
export function handleResize(renderer, camera, container) {
  const width = container.clientWidth;
  const height = container.clientHeight;

  renderer.setSize(width, height);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}
