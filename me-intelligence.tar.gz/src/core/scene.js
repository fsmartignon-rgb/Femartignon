import * as THREE from 'three';

/**
 * Creates the main scene with dark background.
 */
export function createScene() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x020408);
  return scene;
}
