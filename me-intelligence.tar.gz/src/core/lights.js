import * as THREE from 'three';

/**
 * Lighting setup:
 *   - Directional light as sun (drives day/night on the custom shader)
 *   - Soft ambient fill so the night side isn't pure black
 *   - Hemisphere light for subtle atmospheric color variation
 */
export function createLights(scene) {
  // Sun
  const sun = new THREE.DirectionalLight(0xfff5e6, 2.8);
  sun.position.set(150, 60, 100);
  scene.add(sun);

  // Ambient fill
  const ambient = new THREE.AmbientLight(0x223355, 0.15);
  scene.add(ambient);

  // Hemisphere — sky blue to ground warm
  const hemi = new THREE.HemisphereLight(0x4488cc, 0x332211, 0.12);
  scene.add(hemi);

  return { sun, ambient, hemi };
}

/**
 * Returns normalized sun direction vector for shaders.
 */
export function getSunDirection(sun) {
  return sun.position.clone().normalize();
}
