import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

/**
 * Configures OrbitControls with:
 * - Smooth damping for inertia
 * - Auto-rotate
 * - Distance constraints to prevent clipping
 */
export function createControls(camera, domElement) {
  const controls = new OrbitControls(camera, domElement);

  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.rotateSpeed = 0.4;
  controls.zoomSpeed = 0.8;
  controls.panSpeed = 0.5;
  controls.enablePan = false;

  controls.autoRotate = true;
  controls.autoRotateSpeed = 0.35;

  controls.minDistance = 120;
  controls.maxDistance = 500;

  return controls;
}
