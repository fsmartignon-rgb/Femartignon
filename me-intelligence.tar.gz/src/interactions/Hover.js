import * as THREE from 'three';

/**
 * Raycaster-based hover detection for city markers and hub markers.
 * Reports the hovered object's data to a callback.
 */
export class Hover {
  constructor(camera, domElement) {
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2(-999, -999);
    this.camera = camera;
    this.domElement = domElement;
    this.targets = [];  // meshes to test against
    this.onHover = null; // callback: (data, screenPos) | null
    this.currentHit = null;

    this._onMouseMove = this._onMouseMove.bind(this);
    domElement.addEventListener('mousemove', this._onMouseMove);
  }

  /** Register meshes/instancedMeshes to raycast against. */
  setTargets(targets) {
    this.targets = targets;
  }

  _onMouseMove(event) {
    const rect = this.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this._screenPos = { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  /** Call once per frame in the render loop. */
  update(citiesLayer) {
    this.raycaster.setFromCamera(this.mouse, this.camera);

    let hit = null;

    for (const target of this.targets) {
      const intersects = this.raycaster.intersectObject(target, false);
      if (intersects.length > 0) {
        const inter = intersects[0];

        if (target.isInstancedMesh && citiesLayer) {
          // InstancedMesh — resolve city data by instanceId
          const city = citiesLayer.getCityAt(inter.instanceId);
          if (city) {
            hit = { type: 'city', data: city, screenPos: this._screenPos };
          }
        } else if (inter.object.userData?.type === 'hub') {
          hit = { type: 'hub', data: inter.object.userData.data, screenPos: this._screenPos };
        }

        if (hit) break;
      }
    }

    // Notify on change
    if (hit !== this.currentHit) {
      this.currentHit = hit;
      this.domElement.style.cursor = hit ? 'pointer' : 'grab';
      if (this.onHover) this.onHover(hit);
    }
  }

  dispose() {
    this.domElement.removeEventListener('mousemove', this._onMouseMove);
  }
}
