/**
 * Tooltip overlay for globe interactions.
 * Positioned via screen coordinates from the Hover module.
 * Pure DOM — no Three.js dependency.
 */

const BRL = (v) =>
  'R\u00a0' +
  (v >= 1e6
    ? (v / 1e6).toFixed(1).replace('.', ',') + 'M'
    : v >= 1e3
      ? (v / 1e3).toFixed(0) + 'k'
      : v.toFixed(0));

const NUM = (v) => v.toLocaleString('pt-BR');

export class Tooltip {
  constructor(container) {
    this.el = document.createElement('div');
    this.el.className = 'globe-tooltip';
    this.el.style.cssText = `
      position: absolute; z-index: 20; pointer-events: none; display: none;
      background: rgba(10, 14, 22, 0.92); backdrop-filter: blur(14px) saturate(1.3);
      border: 1px solid rgba(255,255,255,0.08); border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.55); padding: 14px 16px;
      font-family: Inter, sans-serif; font-size: 12px; color: #e8ecf1;
      min-width: 180px; transition: opacity 0.15s;
    `;
    container.appendChild(this.el);
    this.container = container;
  }

  show(hit) {
    if (!hit || !hit.data) {
      this.hide();
      return;
    }

    const d = hit.data;

    if (hit.type === 'city') {
      this.el.innerHTML = `
        <div style="font-size:14px;font-weight:800;letter-spacing:-.01em">${d.cidade}</div>
        <div style="font-size:10px;color:#6b7a8d;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-top:1px">${d.pais}</div>
        <div style="margin-top:10px;display:grid;gap:5px">
          <div style="display:flex;justify-content:space-between;gap:18px;color:#8b95a5">Eventos<b style="color:#e8ecf1;font-weight:700;font-variant-numeric:tabular-nums">${NUM(d.eventos)}</b></div>
          <div style="display:flex;justify-content:space-between;gap:18px;color:#8b95a5">PO total<b style="color:#e8ecf1;font-weight:700;font-variant-numeric:tabular-nums">${BRL(d.po)}</b></div>
          <div style="display:flex;justify-content:space-between;gap:18px;color:#8b95a5">Pago<b style="color:#e8ecf1;font-weight:700;font-variant-numeric:tabular-nums">${BRL(d.pago)}</b></div>
        </div>`;
    } else if (hit.type === 'hub') {
      this.el.innerHTML = `
        <div style="font-size:14px;font-weight:800;color:#d4a340">${d.nome}</div>
        <div style="font-size:11px;color:#8b95a5;margin-top:4px">Hub de congressos internacionais</div>`;
    }

    // Position near mouse, clamped to container bounds
    if (hit.screenPos) {
      const maxX = this.container.clientWidth - 210;
      const maxY = this.container.clientHeight - 160;
      this.el.style.left = Math.min(hit.screenPos.x + 18, maxX) + 'px';
      this.el.style.top = Math.min(hit.screenPos.y + 18, maxY) + 'px';
    }

    this.el.style.display = 'block';
    this.el.style.opacity = '1';
  }

  hide() {
    this.el.style.opacity = '0';
    setTimeout(() => { this.el.style.display = 'none'; }, 150);
  }
}
