/**
 * Region filter state management.
 * Controls which cities are displayed on the globe and triggers
 * camera transitions to the selected region.
 */

const REGIONS = {
  Global:           (cities) => cities,
  Brasil:           (cities) => cities.filter((c) => c.pais === 'Brasil'),
  'América do Norte': (cities) => cities.filter((c) => ['EUA', 'Canadá', 'México'].includes(c.pais)),
  Europa:           (cities) => cities.filter((c) => c.cont === 'Europa'),
  'Ásia':           (cities) => cities.filter((c) => c.cont === 'Ásia'),
};

const VIEWS = {
  Global:             { lat: 20, lng: -20, alt: 300 },
  Brasil:             { lat: -15, lng: -50, alt: 175 },
  'América do Norte': { lat: 38, lng: -96, alt: 200 },
  Europa:             { lat: 50, lng: 10, alt: 165 },
  'Ásia':             { lat: 15, lng: 100, alt: 260 },
};

export class Filters {
  constructor() {
    this.current = 'Global';
    this.onChange = null; // callback: (regionName, filteredCities, cameraTarget) => void
  }

  get regionNames() {
    return Object.keys(REGIONS);
  }

  /** Apply a region filter. */
  apply(regionName, allCities) {
    if (!REGIONS[regionName]) return;
    this.current = regionName;
    const filtered = REGIONS[regionName](allCities);
    const view = VIEWS[regionName];
    if (this.onChange) this.onChange(regionName, filtered, view);
  }

  /** Create filter button elements. Returns the container div. */
  createUI(container, allCities) {
    const wrap = document.createElement('div');
    wrap.className = 'globe-filter-bar';
    wrap.style.cssText = `
      position:absolute; top:16px; right:16px; z-index:10;
      display:flex; gap:6px; flex-wrap:wrap;
    `;

    for (const name of this.regionNames) {
      const btn = document.createElement('button');
      btn.textContent = name;
      btn.className = 'fb' + (name === this.current ? ' on' : '');
      btn.style.cssText = `
        font-family:Inter,sans-serif; font-size:10px; font-weight:600;
        letter-spacing:.06em; padding:7px 13px; border-radius:8px;
        border:1px solid rgba(255,255,255,0.06);
        background:rgba(10,14,22,0.82); backdrop-filter:blur(12px);
        color:#8b95a5; cursor:pointer; transition:.18s;
      `;
      btn.addEventListener('mouseenter', () => {
        if (!btn.classList.contains('on')) btn.style.borderColor = 'rgba(235,0,40,0.3)';
      });
      btn.addEventListener('mouseleave', () => {
        if (!btn.classList.contains('on')) btn.style.borderColor = 'rgba(255,255,255,0.06)';
      });
      btn.addEventListener('click', () => {
        wrap.querySelectorAll('button').forEach((b) => {
          b.classList.remove('on');
          b.style.background = 'rgba(10,14,22,0.82)';
          b.style.color = '#8b95a5';
          b.style.borderColor = 'rgba(255,255,255,0.06)';
        });
        btn.classList.add('on');
        btn.style.background = '#eb0028';
        btn.style.color = '#fff';
        btn.style.borderColor = '#eb0028';
        this.apply(name, allCities);
      });
      wrap.appendChild(btn);
    }

    container.appendChild(wrap);
    return wrap;
  }
}
